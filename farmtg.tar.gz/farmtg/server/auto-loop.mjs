#!/usr/bin/env node
/**
 * FarmTG auto-loop — fixed: ???
 *
 * Plant ??? on every available plot.
 *
 * Daily routine (every 3 loops):
 *   1. Steal crops — friends first (free), then paid visits (1000 coins each, max 3)
 *   2. Put weeds/pests on visited farms ? completes daily tasks
 *   3. Clean own marks (weed/pest)
 *   4. Claim unlocked tasks + unread mails
 */

import { spawn, execSync } from "node:child_process";
import { readFileSync, existsSync, writeFileSync, unlinkSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { FarmtgClient } from "./farmtg-client.mjs";

const __dir = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dir, "..");
const JWT_FILE = join(ROOT, ".farmtg_jwt");
const DAILY_STATE_FILE = join(ROOT, ".daily_state.json");
const CHALLENGE_STATE_FILE = join(ROOT, ".challenge_state.json");
const HUMAN_PASS_FILE = join(ROOT, ".farmtg_human_pass");
const CAPTCHA_TOKEN_FILE = join(ROOT, ".farmtg_captcha_token");
const GAME_ORIGIN = "https://farmtg.top";

// Fixed crop: ???
const CROP_CABBAGE = "69f862b32c24a6892a6110d0";  // ?? (300s, 3600 coins/hr)
const CROP_RADISH  = "69f85a3a2c24a6892a6110bf";  // ??? (60s, 600 coins/hr)

const CROP_PRIORITY = [CROP_RADISH];

const CROP_NAMES = {
  [CROP_CABBAGE]: "??",
  [CROP_RADISH]: "???",
};

const CROP_INTERVAL_MS = {
  [CROP_CABBAGE]: 302_000,
  [CROP_RADISH]: 62_000,
};

const DEFAULT_LOOP_INTERVAL_MS = CROP_INTERVAL_MS[CROP_RADISH];
const DAILY_EVERY_LOOPS = 3;       // run daily routine every 3 loops
const MAX_PAID_VISITS   = 3;       // max paid visits per daily run (3000 coins/day)

const CHALLENGE_BASE_MS = 10 * 60 * 1000;
const CHALLENGE_MAX_MS = 60 * 60 * 1000;
const HUMAN_VERIFY_PATH = "/api/game/human-verify";

// --- JWT ---------------------------------------------------------------------

function readJwt() {
  if (process.env.FARMTG_JWT) return process.env.FARMTG_JWT.trim();
  if (existsSync(JWT_FILE)) return readFileSync(JWT_FILE, "utf8").trim();
  throw new Error(`No JWT. Run: python3 ${join(ROOT, "get_farmtg_jwt.py")}`);
}

function readHumanPass() {
  if (process.env.FARMTG_HUMAN_PASS) {
    const value = process.env.FARMTG_HUMAN_PASS.trim();
    if (value) return value;
  }

  try {
    const value = readFileSync(HUMAN_PASS_FILE, "utf8").trim();
    if (value) return value;
  } catch {}

  return "";
}

function parseCaptchaToken(raw) {
  const text = String(raw || "").trim();
  if (!text) return "";

  if (text.includes("\n")) {
    const firstLine = text.split(/\r?\n/).map((x) => x.trim()).find((x) => x);
    if (firstLine) return parseCaptchaToken(firstLine);
    return "";
  }

  try {
    const json = JSON.parse(text);
    if (typeof json?.token === "string") return json.token.trim();
    if (typeof json?.captcha_token === "string") return json.captcha_token.trim();
    if (typeof json?.data?.token === "string") return json.data.token.trim();
    if (typeof json?.data?.captcha_token === "string") return json.data.captcha_token.trim();
    if (typeof json?.solution === "string") return json.solution.trim();
    if (typeof json?.text === "string") return json.text.trim();
  } catch {}

  return text;
}

function readCaptchaToken() {
  if (process.env.FARMTG_CAPTCHA_TOKEN) {
    const envToken = parseCaptchaToken(process.env.FARMTG_CAPTCHA_TOKEN);
    if (envToken) return envToken;
  }

  if (process.env.FARMTG_CAPTCHA_TOKEN_FILE) {
    try {
      const token = parseCaptchaToken(readFileSync(process.env.FARMTG_CAPTCHA_TOKEN_FILE, "utf8"));
      if (token) return token;
    } catch {}
  }

  if (existsSync(CAPTCHA_TOKEN_FILE)) {
    try {
      const token = parseCaptchaToken(readFileSync(CAPTCHA_TOKEN_FILE, "utf8"));
      if (token) return token;
    } catch {}
  }

  const cmd = process.env.FARMTG_CAPTCHA_TOKEN_CMD || "";
  if (!cmd) return "";

  try {
    const output = execSync(cmd, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: 120_000 }).trim();
    return parseCaptchaToken(output);
  } catch (e) {
    console.warn(`[challenge] 人机验证码命令执行失败: ${e.message}`);
    return "";
  }
}

function tryJsonText(value) {
  if (!value) return "";
  if (typeof value === "string") return value;
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}
function clearCaptchaTokenFile(reason) {
  try {
    if (existsSync(CAPTCHA_TOKEN_FILE)) {
      unlinkSync(CAPTCHA_TOKEN_FILE);
      console.warn("[challenge] 已清理无效验证码 token: " + reason);
    }
  } catch (e) {
    console.warn("[challenge] 清理验证码 token 失败: " + e.message);
  }
}

function isInvalidCaptchaResponse(data) {
  const text = tryJsonText(data).toLowerCase();
  return text.includes("invalid-input-response")
    || text.includes("timeout-or-duplicate")
    || text.includes("invalid-input-secret")
    || text.includes("bad-request");
}

async function requestHumanPass(jwt, captchaToken) {
  if (!captchaToken) return false;

  const res = await apiPost(HUMAN_VERIFY_PATH, jwt, { captcha_token: captchaToken });
  if (!res.ok) {
    const detail = tryJsonText(res.data) || String(res.data || "");
    console.warn(`[challenge] 人机验证码兑换失败: ${detail}`);
    if (isInvalidCaptchaResponse(res.data)) {
      clearCaptchaTokenFile("invalid captcha response");
    }
    return false;
  }

  const data = res.data?.data ? res.data.data : res.data;
  const humanPass = typeof data?.human_pass === "string" ? data.human_pass.trim() : "";
  if (!humanPass) {
    console.warn("[challenge] 人机验证码接口未返回 human_pass");
    return false;
  }

  try {
    writeFileSync(HUMAN_PASS_FILE, humanPass);
  } catch {}

  try {
    if (existsSync(CAPTCHA_TOKEN_FILE)) unlinkSync(CAPTCHA_TOKEN_FILE);
  } catch {}

  const expireText = Number.isFinite(Number(data?.expires_in)) ? `${data.expires_in} 秒` : "?";
  console.log(`[challenge] 成功更新人机凭证 ${humanPass.slice(0, 8)}…（剩余 ${expireText}）`);
  return true;
}

async function tryAutoVerify(jwt) {
  const token = readCaptchaToken();
  if (!token) return false;
  return await requestHumanPass(jwt, token);
}

function jwtExpiresAt(jwt) {
  try {
    const raw = jwt.split(".")[1];
    const payload = JSON.parse(Buffer.from(raw, "base64url").toString());
    return payload.exp * 1000;
  } catch { return 0; }
}

async function ensureJwt(current) {
  if (jwtExpiresAt(current) - Date.now() > 10 * 60 * 1000) return current;
  console.log("[jwt] ????,???...");
  await new Promise((resolve, reject) => {
    const proc = spawn("python3", [join(ROOT, "get_farmtg_jwt.py")], { stdio: "inherit" });
    proc.on("close", (code) => code === 0 ? resolve() : reject(new Error(`refresh exited ${code}`)));
  });
  return readJwt();
}

// --- challenge state --------------------------------------------------------

function loadChallengeState() {
  try {
    const state = JSON.parse(readFileSync(CHALLENGE_STATE_FILE, "utf8"));
    const now = Date.now();
    return {
      failures: Number(state.failures) || 0,
      challengePauseUntil: Number(state.challengePauseUntil) || 0,
      lastError: state.lastError || null,
      notified: Boolean(state.notified),
      ...state,
      challengePauseUntil: (state.challengePauseUntil || 0) > now ? state.challengePauseUntil : 0,
    };
  } catch {
    return { failures: 0, challengePauseUntil: 0, lastError: null, notified: false };
  }
}

function saveChallengeState(state) {
  try { writeFileSync(CHALLENGE_STATE_FILE, JSON.stringify(state)); } catch {}
}

function clearChallengeState() {
  const next = { failures: 0, challengePauseUntil: 0, lastError: null, notified: false };
  saveChallengeState(next);
  return next;
}

function applyChallengeFailure(state, err, loopNum) {
  const failures = (state.failures || 0) + 1;
  const base = Math.max(1, failures - 1);
  const backoffMs = Math.min(CHALLENGE_MAX_MS, CHALLENGE_BASE_MS * (2 ** base));

  const next = {
    failures,
    challengePauseUntil: Date.now() + backoffMs,
    lastError: {
      time: new Date().toISOString(),
      loop: loopNum,
      message: String(err?.message || ""),
      action: err?.action || null,
      code: err?.code || null,
    },
    notified: false,
  };

  saveChallengeState(next);
  return next;
}

function classifyFailure(err) {
  const msg = String(err?.message || "").toLowerCase();
  const code = String(err?.code || "").toLowerCase();
  const keys = [
    "challenge",
    "cloudflare",
    "captcha",
    "turnstile",
    "x-human-pass",
    "human-pass",
    "need_human_verification",
    "need human verification",
    "human verification",
    "??????",
    "forbidden",
    "unauthorized",
    "auth",
    "blocked",
    "permission denied",
    "ray-id",
    "429",
    "403",
  ];

  return keys.some((key) => msg.includes(key) || code.includes(key)) ? "challenge" : "action";
}

async function takeChallengePause(state, jwt) {
  if (!state?.challengePauseUntil || state.challengePauseUntil <= Date.now()) {
    if (state?.challengePauseUntil) {
      state = clearChallengeState();
    }
    return { paused: false, state, waitMs: 0 };
  }

  const autoVerified = await tryAutoVerify(jwt);
  if (autoVerified) {
    console.log("[challenge] 人机验证已自动完成，退出暂停");
    state = clearChallengeState();
    return { paused: false, state, waitMs: 0 };
  }

  const manualPass = readHumanPass();
  if (manualPass) {
    console.log("[challenge] 检测到人工校验凭证，退出暂停，继续运行");
    state = clearChallengeState();
    return { paused: false, state, waitMs: 0 };
  }

  const waitMs = state.challengePauseUntil - Date.now();
  if (!state.notified) {
    console.warn(`[challenge] ?? Cloudflare ????,???? ${Math.ceil(waitMs / 1000)} ?`);
    console.warn(`        ??: ${state.lastError?.message || "?"}`);
    console.warn(`        ????:? ${HUMAN_PASS_FILE} ???????? token,??? FARMTG_HUMAN_PASS ?????????`);
    state.notified = true;
    saveChallengeState(state);
  }

  return { paused: true, state, waitMs };
}

// --- HTTP ---------------------------------------------------------------------

function buildHeaders(jwt) {
  const headers = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${jwt}`,
    "Origin": GAME_ORIGIN,
    "Referer": GAME_ORIGIN + "/",
    "User-Agent": "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36",
  };

  const humanPass = readHumanPass();
  if (humanPass) {
    headers["X-Human-Pass"] = humanPass;
  }

  return headers;
}

async function apiGet(path, jwt) {
  const res = await fetch(`${GAME_ORIGIN}${path}`, { headers: buildHeaders(jwt) });
  const text = await res.text();
  return { ok: res.ok, status: res.status, data: tryJson(text) };
}

async function apiPost(path, jwt, body = {}) {
  const res = await fetch(`${GAME_ORIGIN}${path}`, {
    method: "POST",
    headers: buildHeaders(jwt),
    body: JSON.stringify(body),
  });
  const text = await res.text();
  return { ok: res.ok, status: res.status, data: tryJson(text) };
}

function tryJson(text) {
  try { return JSON.parse(text); } catch { return text; }
}

// --- Daily state (track visited players to avoid double-paying) --------------

function loadDailyState() {
  try {
    const raw = JSON.parse(readFileSync(DAILY_STATE_FILE, "utf8"));
    const today = new Date().toISOString().slice(0, 10);
    if (raw.date === today) return raw;
  } catch {}
  return { date: new Date().toISOString().slice(0, 10), visited: [] };
}

function saveDailyState(state) {
  try { writeFileSync(DAILY_STATE_FILE, JSON.stringify(state)); } catch {}
}

// --- Auto-accept friend requests ---------------------------------------------

async function acceptFriendRequests(jwt) {
  let page = 1, accepted = 0;
  while (true) {
    const r = await apiGet(`/api/game/friend-requests?status=pending&page=${page}&page_size=20`, jwt);
    const items = r.data?.data ?? [];
    if (items.length === 0) break;
    for (const req of items) {
      const ar = await apiPost(`/api/game/friend-requests/${req.id}/accept`, jwt);
      if (ar.ok) {
        console.log(`  [friend] ??????: ${req.from_first_name} (lv${req.from_level})`);
        accepted++;
      }
    }
    if (items.length < 20) break;
    page++;
  }
  return accepted;
}

// --- Task / mail claiming ----------------------------------------------------

async function claimMails(jwt) {
  const r = await apiGet("/api/game/mails", jwt);
  const mails = Array.isArray(r.data) ? r.data : (r.data?.data ?? []);
  let n = 0;
  for (const mail of mails) {
    if (!mail.reward_claimed && mail.id) {
      const cr = await apiPost(`/api/game/mails/${mail.id}/claim`, jwt);
      if (cr.ok) { console.log(`  [mail] ??: ${mail.title ?? mail.id}`); n++; }
    }
  }
  return n;
}

async function claimTasks(jwt) {
  const r = await apiGet("/api/game/tasks", jwt);
  const tasks = Array.isArray(r.data) ? r.data : (r.data?.data ?? []);
  let n = 0;
  for (const task of tasks) {
    if (task.status === "todo" && task.progress_percent === 100 && task.task_code) {
      const cr = await apiPost(`/api/game/tasks/${encodeURIComponent(task.task_code)}/claim`, jwt);
      if (cr.ok) { console.log(`  [task] ??: ${task.name ?? task.task_code}`); n++; }
    }
  }
  return n;
}

// --- Daily: clean own farm marks ---------------------------------------------

async function cleanOwnMarks(jwt) {
  let cleaned = 0;
  for (const cleanType of ["weeds", "worm"]) {
    const r = await apiPost("/api/game/clean-marks", jwt, { clean_type: cleanType });
    if (r.ok && r.data?.cleaned_count > 0) {
      console.log(`  [clean] ?? ${cleanType} ×${r.data.cleaned_count}`);
      cleaned += r.data.cleaned_count;
    }
  }
  return cleaned;
}

// --- Daily: steal crops + put marks ------------------------------------------

async function dailyRoutine(jwt) {
  console.log("[daily] ??????...");
  const state = loadDailyState();
  const today = new Date().toISOString().slice(0, 10);
  if (state.date !== today) {
    state.date = today;
    state.visited = [];
  }

  // 1. Get players — prefer friends, then random
  const playersRes = await apiGet("/api/game/all-players?page=1&page_size=50", jwt);
  const players = playersRes.data?.data ?? [];
  const friends = players.filter((p) => p.is_friend);
  const others = players.filter((p) => !p.is_friend);
  const candidates = [...friends, ...others];

  let weedPut = 0, pestPut = 0, stealOk = 0, paidVisits = 0;

  for (const player of candidates) {
    if (weedPut >= 5 && pestPut >= 5 && stealOk >= 10) break;

    const key = player.player_key;
    const alreadyVisited = state.visited.includes(key);

    // Visit if non-friend and not yet visited today
    if (!player.is_friend && !alreadyVisited) {
      if (paidVisits >= MAX_PAID_VISITS) continue;
      const vr = await apiPost("/api/game/visit", jwt, { target_key: key });
      if (!vr.ok) continue;
      paidVisits++;
      state.visited.push(key);
      saveDailyState(state);
      console.log(`  [visit] ?? ${player.first_name},?? ${vr.data?.charged_coins ?? 1000} ??`);
    }

    // Get their farm plots
    const farmRes = await apiGet(`/api/game/friend-farm?target_key=${encodeURIComponent(key)}`, jwt);
    const farmPlots = farmRes.data?.plots ?? [];
    const activePlots = farmPlots.filter((p) => p.stage !== "empty" && p.stage !== "cleared");

    // Put marks on growth/mature plots (mark_type: "weeds" | "worm")
    const growingPlots = activePlots.filter((p) => p.stage === "growth" || p.stage === "mature");
    for (const plot of growingPlots.slice(0, 2)) {
      if (weedPut < 5) {
        const mr = await apiPost("/api/game/friend-farm/mark", jwt, {
          target_key: key, plot_index: plot.plot_index, mark_type: "weeds",
        });
        if (mr.ok && mr.data?.ok !== false) { weedPut++; }
      }
      if (pestPut < 5) {
        const mr = await apiPost("/api/game/friend-farm/mark", jwt, {
          target_key: key, plot_index: plot.plot_index, mark_type: "worm",
        });
        if (mr.ok && mr.data?.ok !== false) { pestPut++; }
      }
    }

    // Help clear their clearable marks
    const clearable = farmRes.data?.friend_marks_clearable ?? {};
    for (const [, marks] of Object.entries(clearable)) {
      for (const markType of (Array.isArray(marks) ? marks : [marks])) {
        await apiPost("/api/game/friend-farm/clean", jwt, {
          target_key: key, clean_type: markType,
        }).catch(() => {});
      }
    }

    // Steal crops
    const sr = await apiPost("/api/game/steal-crops", jwt, { target_key: key });
    if (sr.data?.ok && sr.data?.stolen?.length > 0) {
      stealOk++;
      const crops = sr.data.stolen.map((s) => `${s.crop_name}×${s.count}`).join(", ");
      console.log(`  [steal] ??: ${crops} ? ${player.first_name}`);
    } else if (sr.data?.pet_blocked) {
      // skip silently
    }
  }

  // 2. Clean own marks
  await cleanOwnMarks(jwt);

  // 3. Claim tasks that completed from daily activities
  const tc = await claimTasks(jwt);
  if (tc > 0) console.log(`  [daily] ?? ${tc} ?????`);

  console.log(`[daily] ??: ?×${weedPut} ?×${pestPut} ?=${stealOk} ????=${paidVisits}`);
}

function plotCropId(plot) {
  return plot?.crop_id ?? plot?.cropId ?? plot?.crop?.id ?? plot?.crop?.crop_id ?? null;
}

function chooseNextLoopInterval(plantedCropIds, client) {
  const activeCropIds = new Set(plantedCropIds);
  for (const plot of client.state.plots ?? []) {
    const id = plotCropId(plot);
    if (id) activeCropIds.add(id);
  }

  if (activeCropIds.has(CROP_CABBAGE)) return CROP_INTERVAL_MS[CROP_CABBAGE];
  if (activeCropIds.has(CROP_RADISH)) return CROP_INTERVAL_MS[CROP_RADISH];
  return DEFAULT_LOOP_INTERVAL_MS;
}

// --- One automation tick -----------------------------------------------------

async function tick(client, jwt, loopNum) {
  const t0 = Date.now();

  // 1. Harvest all (server decides maturity — client progress may be stale)
  let harvested = 0;
  try {
    const hVersion = client.plotsVersion;
    const hr = await client.harvestAll();
    harvested = hr.data?.harvested_count ?? 0;
    if (harvested > 0) {
      await client.waitForPlots({ afterVersion: hVersion, timeoutMs: 5_000 }).catch(() => {});
    }
  } catch (e) {
    if (classifyFailure(e) === "challenge") {
      throw e;
    }
    console.warn(`  [harvest] ??: ${e.message}`);
  }

  // 2. Clear withered plots first
  const witheredPlots = client.getWitheredPlots();
  for (const plotIndex of witheredPlots) {
    const cr = await client.action("clear_plot", { plot_index: plotIndex }).catch((e) => {
      if (classifyFailure(e) === "challenge") throw e;
      return null;
    });
    if (cr?.ok) console.log(`  [clear] ?????? plot ${plotIndex}`);
  }

  // 3. Plant on empty plots — COINS-first order
  const inv = await client.refreshInventory();
  const findSeed = (cropId) => inv.find((i) => i.crop_id === cropId);
  const seeds = Object.fromEntries(CROP_PRIORITY.map((id) => [id, findSeed(id)]));

  const emptyPlots = client.getEmptyPlots();
  let planted = 0;
  let lastCropId = null;
  const plantedCropIds = new Set();
  for (const plotIndex of emptyPlots) {
    const cropId = CROP_PRIORITY.find((id) => (seeds[id]?.count ?? 0) > 0);
    if (!cropId) { console.log(`  [plant] ?????`); break; }
    seeds[cropId].count -= 1;
    try {
      const pr = await client.plant(plotIndex, cropId);
      if (pr.ok) { planted++; lastCropId = cropId; plantedCropIds.add(cropId); }
    } catch (e) {
      if (classifyFailure(e) === "challenge") {
        throw e;
      }
      console.warn(`  [plant] plot ${plotIndex} ??`);
    }
  }

  // 3. Every 5 loops: claim tasks/mails
  if (loopNum % 5 === 0) {
    const mc = await claimMails(jwt);
    const tc = await claimTasks(jwt);
    if (mc + tc > 0) console.log(`  [claim] mail=${mc} task=${tc}`);
  }

  const elapsed = Date.now() - t0;
  const u = client.state.user ?? {};
  const seedCounts = CROP_PRIORITY
    .map((id) => `${CROP_NAMES[id]}×${seeds[id]?.count ?? 0}`)
    .filter((s) => !s.endsWith("×0"))
    .join(" ") || "???";
  if (harvested > 0 || planted > 0 || loopNum % 10 === 0) {
    console.log(`[tick ${loopNum}] lv=${u.level} exp=${u.exp} coins=${u.coins} | ??=${harvested} ??=${planted}(${lastCropId ? CROP_NAMES[lastCropId] : "-"}) | ${seedCounts} | ${elapsed}ms`);
  }

  return chooseNextLoopInterval(plantedCropIds, client);
}

// --- Main --------------------------------------------------------------------

let jwt = readJwt();
const expStr = new Date(jwtExpiresAt(jwt)).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" });
console.log(`[start] JWT ????: ${expStr}`);
console.log(`[start] ????: ????? (60s??)`);
console.log(`[start] ????: 62s | ????? ${DAILY_EVERY_LOOPS} ?`);

let client = null;
let loopNum = 0;
let nextLoopIntervalMs = CROP_INTERVAL_MS[CROP_RADISH];
let running = true;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let challengeState = loadChallengeState();
if (challengeState.challengePauseUntil && challengeState.challengePauseUntil > Date.now()) {
  console.log(`[challenge] ??????????????`);
}

process.on("SIGINT",  () => { running = false; console.log("\n[stop] ???..."); client?.close(); });
process.on("SIGTERM", () => { running = false; client?.close(); });

async function connectClient(token) {
  const c = new FarmtgClient({
    token,
    wsUrl: "wss://farmtg.top/api/game/ws",
    humanPass: readHumanPass(),
  });
  await c.connect();
  await c.waitForPlots();
  return c;
}

async function connectClientWithRetry() {
  let attempt = 0;
  while (running) {
    try {
      jwt = await ensureJwt(jwt);
      await tryAutoVerify(jwt);
      return await connectClient(jwt);
    } catch (err) {
      attempt++;
      const isChallenge = classifyFailure(err) === "challenge";
      const state = isChallenge ? "[challenge]" : "[ws]";
      if (isChallenge) {
        const ok = await tryAutoVerify(jwt);
        if (ok) {
          console.log("[challenge] 已自动完成启动阶段人机校验，立即重试连接");
          continue;
        }
      }
      console.error(`${state} 启动连接失败 ` + attempt + ": " + err.message + "; 60s 后重试");
      await sleep(60_000);
    }
  }
  throw new Error("Stopped before FarmTG WebSocket connected");
}

client = await connectClientWithRetry();
const u0 = client.state.user ?? {};
console.log(`[connected] lv=${u0.level} exp=${u0.exp} coins=${u0.coins} plots=${u0.unlocked_plots}`);

// Startup: accept friend requests, claim everything, run daily routine
await acceptFriendRequests(jwt);
await claimMails(jwt);
await claimTasks(jwt);
await dailyRoutine(jwt);

// Main loop
while (running) {
  const gate = await takeChallengePause(challengeState, jwt);
  if (gate.paused) {
    challengeState = gate.state;
    await sleep(Math.min(gate.waitMs, nextLoopIntervalMs));
    continue;
  }

  loopNum++;
  try {
    jwt = await ensureJwt(jwt);

    if (!client?.ws || client.ws.readyState > 1) {
      console.log("[ws] ???...");
      client?.close();
      client = await connectClient(jwt);
    }

    nextLoopIntervalMs = await tick(client, jwt, loopNum);

    // Daily routine every DAILY_EVERY_LOOPS iterations
    if (loopNum % DAILY_EVERY_LOOPS === 0) {
      await acceptFriendRequests(jwt);
      await dailyRoutine(jwt);
    }

    challengeState = clearChallengeState();
  } catch (err) {
    if (classifyFailure(err) === "challenge") {
      const ok = await tryAutoVerify(jwt);
      if (ok) {
        console.log(`[challenge] loop ${loopNum}: 自动完成验证，恢复运行`);
        challengeState = clearChallengeState();
        client?.close();
        client = await connectClient(jwt);
        nextLoopIntervalMs = 60_000;
      } else {
        challengeState = applyChallengeFailure(challengeState, err, loopNum);
        console.error(`[challenge] loop ${loopNum}: ${err.message}`);
        console.error(`[challenge] 请在浏览器完成人机验证后，写入 ${HUMAN_PASS_FILE} 或设置 FARMTG_HUMAN_PASS 并重启进程`);
        client?.close();
        client = null;
        nextLoopIntervalMs = 60_000;
      }
    } else {
      console.error(`[error] loop ${loopNum}: ${err.message}`);
      client?.close();
      client = null;
      try { client = await connectClient(jwt); } catch (e2) { console.error("[reconnect failed]", e2.message); }
      challengeState = clearChallengeState();
      nextLoopIntervalMs = 60_000;
    }
  }

  if (!running) break;
  await sleep(nextLoopIntervalMs);
}

client?.close();
console.log("[done]");

